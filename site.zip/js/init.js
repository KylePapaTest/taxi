(function($){
  $(function(){

    $('.button-collapse').sideNav();
    $('.parallax').parallax();
    $('.carousel').carousel();

      
  }); // end of document ready
})(jQuery); // end of jQuery name space

      
    $('.carousel.carousel-slider').carousel({fullWidth: true});

